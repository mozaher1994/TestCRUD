﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SampleCRUD.DAL.Models
{
    public class BusinessEntity
    {
        public long BusinessId { get; set; }
        [Display(Name = "CODE")]
        [Required(ErrorMessage = "Please enter valid code")]
        public string Code { get; set; }
        [Required]
        [Display(Name = "EMAIL")]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$",
                   ErrorMessage = "Entered Email is not valid.")]
        public string Email { get; set; }
        [Display(Name = "NAME")]
        [Required(ErrorMessage = "Please enter a name")]
        public string Name { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }

        [Display(Name = "MOBILE")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{6})$",
                   ErrorMessage = "Entered phone format is not valid.")]
        [Required(ErrorMessage = "Please enter valid mobile no")]
        public string Mobile { get; set; }

        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$",
                   ErrorMessage = "Entered phone format is not valid.")]
        public string Phone { get; set; }
        public string ContactPerson { get; set; }
        public string ReferredBy { get; set; }
        public string Logo { get; set; }
        public int Status { get; set; }
        [Display(Name = "BALANCE(BD)")]
        public decimal Balance { get; set; }
        public string LoginUrl { get; set; }
        public string SecurityCode { get; set; }
        [Display(Name = "MARKUP PLAN")]
        public string MarkupPlan { get; set; }
        public int MarkupPlanId { get; set; }
        public string SMTPServer { get; set; }
        public int SMTPPort { get; set; }
        public string SMTPUsername { get; set; }
        public string SMTPPassword { get; set; }
        public bool Deleted { get; set; }

        [Display(Name = "JOINED ON")]
        public Nullable<System.DateTime> CreatedOnUtc { get; set; }
        public Nullable<System.DateTime> UpdatedOnUtc { get; set; }
        public decimal CurrentBalance { get; set; }

        public bool REGENT { get; set; } 
        public bool NOVO { get; set; } 
        public bool GALILEO { get; set; } 
        public bool USBS { get; set; } 
        public bool INDIGO { get; set; }
        public bool B2B { get; set; }
        public bool B2C { get; set; }
        public bool NEW { get; set; }
        public bool ACTIVE { get; set; }
        public bool INACTIVE { get; set; }
        public bool LOCKED { get; set; }


    }
}