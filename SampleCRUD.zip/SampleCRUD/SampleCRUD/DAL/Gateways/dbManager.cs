﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SampleCRUD.DAL.Gateways
{
    public class dbManager
    {
        private string ConnectionString =
            ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString.ToString();
        public SqlCommand Command { get; set; }
        public SqlConnection SqlConnection { get; set; }
        
        public dbManager()
        {
            SqlConnection = new SqlConnection(ConnectionString);
        }

        public void SelectQuery(SqlCommand command, ref DataSet ds)
        {

            if (command.Connection.State == ConnectionState.Closed)
            {
                command.Connection.Open();
            }
            SqlDataAdapter sda = new SqlDataAdapter(command);
            using (sda)
            {
                sda.Fill(ds);
            }
            command.Connection.Close();
        }
        public int NonSelctQuery(SqlCommand command)
        {
            int rowAffect = 0;
            if (command.Connection.State == ConnectionState.Closed)
            {
                command.Connection.Open();
            }
            rowAffect = command.ExecuteNonQuery();
            command.Connection.Close();
            return rowAffect;
        }
    }


}
