﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using SampleCRUD.DAL.Models;

namespace SampleCRUD.DAL.Gateways
{
    public class CRUDGateway : dbManager
    {
        public int Create(BusinessEntity aBusinessEntity)
        {
            int rowAffect = 0;
            string qry = @"INSERT INTO [dbo].[BusinessEntities]
           ([Code]
           ,[Email]
           ,[Name]
           ,[Street]
           ,[City]
           ,[State]
           ,[Zip]
           ,[Country]
           ,[Mobile]
           ,[Phone]
           ,[ContactPerson]
           ,[ReferredBy]
           ,[Logo]
           ,[Status]
           ,[Balance]
           ,[LoginUrl]
           ,[SecurityCode]
           ,[SMTPServer]
           ,[SMTPPort]
           ,[SMTPUsername]
           ,[SMTPPassword]
           ,[Deleted]
           ,[CreatedOnUtc]
           ,[UpdatedOnUtc]
           ,[CurrentBalance],

REGENT ,
NOVO  ,
GALILEO ,
USBS ,
INDIGO ,
B2B ,
B2C ,
NEW ,
ACTIVE ,
INACTIV ,
LOCKED ,MarkupPlan
)
     VALUES(@Code,@Email,@name,@Street,@City,@State,@Zip,@Country,@Mobile,@Phone,@ContactPerson,@ReferredBy,@Logo,@Status,@Balance,@LoginUrl,@SecurityCode,@SMTPServer,@SMTPPort,@SMTPUsername,@SMTPPassword,@Deleted,@CreatedOnUtc,@UpdatedOnUtc,@CurrentBalance,@REGENT,@NOVO,@GALILEO,@USBS,@INDIGO,@B2B,@B2C,@NEW,@ACTIVE,@INACTIVE, @LOCKED,@MarkupPlan)";
            Command=new SqlCommand(qry,SqlConnection);

            Command.Parameters.Clear();
            Command.Parameters.AddWithValue("@name", aBusinessEntity.Name);
            Command.Parameters.AddWithValue("@Code", aBusinessEntity.Code);
            Command.Parameters.AddWithValue("@Email", aBusinessEntity.Email);
            Command.Parameters.AddWithValue("@Street", aBusinessEntity.Street);
            Command.Parameters.AddWithValue("@City", aBusinessEntity.City);
            Command.Parameters.AddWithValue("@State", aBusinessEntity.State);
            Command.Parameters.AddWithValue("@Zip", aBusinessEntity.Zip);
            Command.Parameters.AddWithValue("@Country", aBusinessEntity.Country);
            Command.Parameters.AddWithValue("@Mobile", aBusinessEntity.Mobile);
            Command.Parameters.AddWithValue("@Phone", aBusinessEntity.Phone);
            Command.Parameters.AddWithValue("@ContactPerson", aBusinessEntity.ContactPerson);
            Command.Parameters.AddWithValue("@ReferredBy", aBusinessEntity.ReferredBy);
            Command.Parameters.AddWithValue("@Logo", aBusinessEntity.Logo);
            Command.Parameters.AddWithValue("@Status", aBusinessEntity.Status);
            Command.Parameters.AddWithValue("@Balance", aBusinessEntity.Balance);
            Command.Parameters.AddWithValue("@LoginUrl", aBusinessEntity.LoginUrl);
            Command.Parameters.AddWithValue("@SecurityCode", aBusinessEntity.SecurityCode);
            Command.Parameters.AddWithValue("@SMTPServer", aBusinessEntity.SMTPServer);
            Command.Parameters.AddWithValue("@SMTPPort", aBusinessEntity.SMTPPort);
            Command.Parameters.AddWithValue("@SMTPUsername", aBusinessEntity.SMTPUsername);
            Command.Parameters.AddWithValue("@SMTPPassword", aBusinessEntity.SMTPPassword);
            Command.Parameters.AddWithValue("@Deleted", aBusinessEntity.Deleted);
            Command.Parameters.AddWithValue("@CreatedOnUtc", aBusinessEntity.CreatedOnUtc);
            Command.Parameters.AddWithValue("@UpdatedOnUtc", aBusinessEntity.UpdatedOnUtc);
            Command.Parameters.AddWithValue("@REGENT", aBusinessEntity.REGENT);
            Command.Parameters.AddWithValue("@NOVO", aBusinessEntity.NOVO);
            Command.Parameters.AddWithValue("@GALILEO", aBusinessEntity.GALILEO);
            Command.Parameters.AddWithValue("@USBS", aBusinessEntity.USBS);
            Command.Parameters.AddWithValue("@INDIGO", aBusinessEntity.INDIGO);
            Command.Parameters.AddWithValue("@B2B", aBusinessEntity.B2B);
            Command.Parameters.AddWithValue("@B2C", aBusinessEntity.B2C);
            Command.Parameters.AddWithValue("@NEW", aBusinessEntity.NEW);
            Command.Parameters.AddWithValue("@ACTIVE", aBusinessEntity.ACTIVE);
            Command.Parameters.AddWithValue("@INACTIVE", aBusinessEntity.INACTIVE);
            Command.Parameters.AddWithValue("@LOCKED", aBusinessEntity.LOCKED);
            Command.Parameters.AddWithValue("@MarkupPlan", aBusinessEntity.MarkupPlanId);
            Command.Parameters.AddWithValue("@CurrentBalance", aBusinessEntity.CurrentBalance);

            rowAffect =NonSelctQuery(Command);

            return rowAffect;
        }
        public int Update(int id,BusinessEntity aBusinessEntity)
        {
            int rowAffect = 0;
            string qry = @"Update [dbo].[BusinessEntities]
           set [Code]=@Code
           ,[Email]=@Email
           ,[Name]=@name
           ,[Street]=@Street
           ,[City]=@City
           ,[State]=@State
           ,[Zip]=@Zip
           ,[Country]=@Country
           ,[Mobile]=@Mobile
           ,[Phone]=@Phone
           ,[ContactPerson]=@ContactPerson
           ,[ReferredBy]=@ReferredBy
           ,[Logo]=@Logo
           ,[Status]=@Status
           ,[Balance]=@Balance
           ,[LoginUrl]=@LoginUrl
           ,[SecurityCode]=@SecurityCode
           ,[SMTPServer]=@SMTPServer
           ,[SMTPPort]=@SMTPPort
           ,[SMTPUsername]=@SMTPUsername
           ,[SMTPPassword]=@SMTPPassword
           ,[Deleted]=@Deleted
           ,[CreatedOnUtc]=@CreatedOnUtc
           ,[UpdatedOnUtc]=@UpdatedOnUtc
           ,REGENT=@REGENT,
NOVO=@NOVO  ,
GALILEO=@GALILEO ,
USBS=@USBS ,
INDIGO=@INDIGO ,
B2B=@B2B ,
B2C=@B2C ,
NEW=@NEW ,
ACTIVE=@ACTIVE ,
INACTIV=@INACTIVE ,
LOCKED=@LOCKED , 
MarkupPlan=@MarkupPlan  

           ,[CurrentBalance]=@CurrentBalance where [BusinessId]=@Id";
            Command = new SqlCommand(qry, SqlConnection);
            Command.Parameters.Clear();
            Command.Parameters.AddWithValue("@Id", id);
            Command.Parameters.AddWithValue("@name", aBusinessEntity.Name);
            Command.Parameters.AddWithValue("@Code", aBusinessEntity.Code);
            Command.Parameters.AddWithValue("@Email", aBusinessEntity.Email);
            Command.Parameters.AddWithValue("@Street", aBusinessEntity.Street);
            Command.Parameters.AddWithValue("@City", aBusinessEntity.City);
            Command.Parameters.AddWithValue("@State", aBusinessEntity.State);
            Command.Parameters.AddWithValue("@Zip", aBusinessEntity.Zip);
            Command.Parameters.AddWithValue("@Country", aBusinessEntity.Country);
            Command.Parameters.AddWithValue("@Mobile", aBusinessEntity.Mobile);
            Command.Parameters.AddWithValue("@Phone", aBusinessEntity.Phone);
            Command.Parameters.AddWithValue("@ContactPerson", aBusinessEntity.ContactPerson);
            Command.Parameters.AddWithValue("@ReferredBy", aBusinessEntity.ReferredBy);
            Command.Parameters.AddWithValue("@Logo", aBusinessEntity.Logo);
            Command.Parameters.AddWithValue("@Status", aBusinessEntity.Status);
            Command.Parameters.AddWithValue("@Balance", aBusinessEntity.Balance);
            Command.Parameters.AddWithValue("@LoginUrl", aBusinessEntity.LoginUrl);
            Command.Parameters.AddWithValue("@SecurityCode", aBusinessEntity.SecurityCode);
            Command.Parameters.AddWithValue("@SMTPServer", aBusinessEntity.SMTPServer);
            Command.Parameters.AddWithValue("@SMTPPort", aBusinessEntity.SMTPPort);
            Command.Parameters.AddWithValue("@SMTPUsername", aBusinessEntity.SMTPUsername);
            Command.Parameters.AddWithValue("@SMTPPassword", aBusinessEntity.SMTPPassword);
            Command.Parameters.AddWithValue("@Deleted", aBusinessEntity.Deleted);
            Command.Parameters.AddWithValue("@CreatedOnUtc", aBusinessEntity.CreatedOnUtc);
            Command.Parameters.AddWithValue("@UpdatedOnUtc", aBusinessEntity.UpdatedOnUtc);
            Command.Parameters.AddWithValue("@CurrentBalance", aBusinessEntity.CurrentBalance);
            Command.Parameters.AddWithValue("@REGENT", aBusinessEntity.REGENT);
            Command.Parameters.AddWithValue("@NOVO", aBusinessEntity.NOVO);
            Command.Parameters.AddWithValue("@GALILEO", aBusinessEntity.GALILEO);
            Command.Parameters.AddWithValue("@USBS", aBusinessEntity.USBS);
            Command.Parameters.AddWithValue("@INDIGO", aBusinessEntity.INDIGO);
            Command.Parameters.AddWithValue("@B2B", aBusinessEntity.B2B);
            Command.Parameters.AddWithValue("@B2C", aBusinessEntity.B2C);
            Command.Parameters.AddWithValue("@NEW", aBusinessEntity.NEW);
            Command.Parameters.AddWithValue("@ACTIVE", aBusinessEntity.ACTIVE);
            Command.Parameters.AddWithValue("@INACTIVE", aBusinessEntity.INACTIVE);
            Command.Parameters.AddWithValue("@LOCKED", aBusinessEntity.LOCKED);
            Command.Parameters.AddWithValue("@MarkupPlan", aBusinessEntity.MarkupPlanId);
            rowAffect = NonSelctQuery(Command);
            return rowAffect;
        }

        public int Delete(int id)
        {
            int rowAffect = 0;
            string qry = @"delete from [BusinessEntities] where [BusinessId]=@Id ";
            Command = new SqlCommand(qry, SqlConnection);
            Command.Parameters.Clear();
            Command.Parameters.AddWithValue("@Id", id);
            rowAffect = NonSelctQuery(Command);
            return rowAffect;
        }
        public void GetData(ref DataSet ds)
        {
            string qry = @"exec [prcGetData]";
            Command = new SqlCommand(qry, SqlConnection);
            SelectQuery(Command, ref ds);
        }

        public void GetanEntityById(int id,ref DataSet ds)
        {
            string qry = @"exec [prcGetData] '"+id+"'";
            Command = new SqlCommand(qry, SqlConnection);
            SelectQuery(Command, ref ds);
        }
    }
}