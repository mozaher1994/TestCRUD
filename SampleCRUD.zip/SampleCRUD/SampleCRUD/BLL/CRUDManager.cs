﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using SampleCRUD.DAL.Gateways;
using SampleCRUD.DAL.Models;

namespace SampleCRUD.BLL
{
    public class CRUDManager
    {
        CRUDGateway aGateway=new CRUDGateway();

        public string Create(BusinessEntity anEntity)
        {
            anEntity.CreatedOnUtc = DateTime.UtcNow;
            anEntity.UpdatedOnUtc = DateTime.UtcNow;
            anEntity.CurrentBalance = 0;
           
            anEntity.ContactPerson ="";
            anEntity.Deleted =false;
            anEntity.LoginUrl ="";
            anEntity.Logo ="";
            anEntity.ReferredBy ="";
            anEntity.SMTPPassword ="";
            anEntity.Country ="";
            anEntity.SMTPPort =0;
            anEntity.SMTPServer ="";
            anEntity.SMTPUsername ="";
            anEntity.SecurityCode ="";
           
            anEntity.Status =0;
            int rowAffect = aGateway.Create(anEntity);
            if (rowAffect>0)
            {
                return "Create Success";
            }
            return "Create Fail";
        }
        public string Update(int id,BusinessEntity anEntity)
        {
            anEntity.CreatedOnUtc = DateTime.UtcNow;
            anEntity.UpdatedOnUtc = DateTime.UtcNow;
            anEntity.CurrentBalance = 0;

            anEntity.ContactPerson = "";
            anEntity.Deleted = false;
            anEntity.LoginUrl = "";
            anEntity.Logo = "";
            anEntity.ReferredBy = "";
            anEntity.SMTPPassword = "";
            anEntity.Country = "";
            anEntity.SMTPPort = 0;
            anEntity.SMTPServer = "";
            anEntity.SMTPUsername = "";
            anEntity.SecurityCode = "";

            anEntity.Status = 0;
            int rowAffect = aGateway.Update(id,anEntity);
            if (rowAffect > 0)
            {
                return "Update Success";
            }
            return "Update Fail";
        }

        public string Delete(int id)
        {
            
            int rowAffect = aGateway.Delete(id);
            if (rowAffect > 0)
            {
                return "Delete Success";
            }
            return "Delete Fail";
        }

        public DataSet GetDate()
        {
            DataSet ds=new DataSet();
            aGateway.GetData(ref ds);
            ds.Tables[0].TableName = "List";
            ds.Tables[1].TableName = "MarkupPlane";
            return ds;
        }

        public BusinessEntity GetanEntityById(int id)
        {
            BusinessEntity anEntity=new BusinessEntity();
            DataSet ds=new DataSet();
            aGateway.GetanEntityById(id,ref ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                anEntity.BusinessId = int.Parse(ds.Tables[0].Rows[0]["BusinessId"].ToString());
                anEntity.Code = ds.Tables[0].Rows[0]["Code"].ToString();
                anEntity.Name = ds.Tables[0].Rows[0]["Name"].ToString();
                anEntity.MarkupPlanId = int.Parse(ds.Tables[0].Rows[0]["MarkupPlan"].ToString());
                anEntity.MarkupPlan = ds.Tables[0].Rows[0]["Plans"].ToString();
                anEntity.Email = ds.Tables[0].Rows[0]["Email"].ToString();
                anEntity.Mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                anEntity.Phone = ds.Tables[0].Rows[0]["Phone"].ToString();
                anEntity.Street = ds.Tables[0].Rows[0]["Street"].ToString();
                anEntity.City = ds.Tables[0].Rows[0]["City"].ToString();
                anEntity.State = ds.Tables[0].Rows[0]["State"].ToString();
                anEntity.Zip = ds.Tables[0].Rows[0]["Zip"].ToString();
                anEntity.REGENT = bool.Parse(ds.Tables[0].Rows[0]["REGENT"].ToString());
                anEntity.NOVO = bool.Parse(ds.Tables[0].Rows[0]["NOVO"].ToString());
                anEntity.GALILEO = bool.Parse(ds.Tables[0].Rows[0]["GALILEO"].ToString());
                anEntity.USBS = bool.Parse(ds.Tables[0].Rows[0]["USBS"].ToString());
                anEntity.INDIGO = bool.Parse(ds.Tables[0].Rows[0]["INDIGO"].ToString());
                anEntity.B2B = bool.Parse(ds.Tables[0].Rows[0]["B2B"].ToString());
                anEntity.B2C = bool.Parse(ds.Tables[0].Rows[0]["B2C"].ToString());
                anEntity.NEW = bool.Parse(ds.Tables[0].Rows[0]["NEW"].ToString());
                anEntity.INACTIVE = bool.Parse(ds.Tables[0].Rows[0]["INACTIV"].ToString());
                anEntity.ACTIVE = bool.Parse(ds.Tables[0].Rows[0]["ACTIVE"].ToString());
                anEntity.LOCKED = bool.Parse(ds.Tables[0].Rows[0]["LOCKED"].ToString());
            }
            
            return anEntity;
        }

        public List<BusinessEntity> GetListDate()
        {
            List<BusinessEntity> list=new List<BusinessEntity>(); 
            DataSet ds = new DataSet();
            ds= GetDate();
            DataTable dt = ds.Tables["List"];
            if (dt.Rows.Count>0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    BusinessEntity anEntity=new BusinessEntity();
                    anEntity.CreatedOnUtc = DateTime.Parse(row.ItemArray[0].ToString());
                    anEntity.Code = row.ItemArray[1].ToString();
                    anEntity.Name = row.ItemArray[2].ToString();
                    anEntity.MarkupPlan = row.ItemArray[3].ToString();
                    anEntity.Mobile = row.ItemArray[4].ToString();
                    anEntity.Email = row.ItemArray[5].ToString();
                    anEntity.Balance = decimal.Parse(row.ItemArray[6].ToString());
                    anEntity.BusinessId = int.Parse(row.ItemArray[7].ToString());
                   
                    list.Add(anEntity);
                }
            }
           
            return list;
        }

    }
}