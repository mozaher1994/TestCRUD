﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SampleCRUD.BLL;
using SampleCRUD.DAL.Models;

namespace SampleCRUD.Controllers
{
    public class SampleCRUDController : Controller
    {
        CRUDManager aManager=new CRUDManager();
        
        // GET: SampleCRUD
        public ActionResult Index()
        {
            List<BusinessEntity> list = new List<BusinessEntity>();
            try
            {
                if (TempData["msg"]!=null)
                {
                    string msg = TempData["msg"].ToString();
                   
                        ViewBag.msg = msg;
                    
                }

                list = GetList();

                return View(list);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            
            
        }

        // GET: SampleCRUD/Details/5
        public ActionResult Details(int id)
        {
            try
            {
                ViewBag.MarkupPlan = GetMarkupData();
                BusinessEntity anEntity = aManager.GetanEntityById(id);
                return View(anEntity);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        // GET: SampleCRUD/Create
        public ActionResult Create()
        {
            ViewBag.MarkupPlan = GetMarkupData();
            return View();
        }

        // POST: SampleCRUD/Create
        [HttpPost]
        public ActionResult Create(BusinessEntity anEntity)
        {
            try
            {

                string msg = aManager.Create(anEntity);
                if (msg== "Create Fail")
                {
                    ViewBag.errmsg = msg;
                    ViewBag.MarkupPlan = GetMarkupData();
                    return View();
                }
                TempData["msg"] = msg + "-SL";
                return RedirectToAction("Index");
            }
            catch(Exception ex)
            {
                ViewBag.errmsg = ex.Message;
                ViewBag.MarkupPlan = GetMarkupData();
                return View();
            }
        }

        // GET: SampleCRUD/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                ViewBag.MarkupPlan = GetMarkupData();
                BusinessEntity anEntity = aManager.GetanEntityById(id);
                return View(anEntity);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            
        }

        // POST: SampleCRUD/Edit/5
        [HttpPost]
        public ActionResult Edit(int BusinessId, BusinessEntity anEntity)
        {
            try
            {

                string msg = aManager.Update(BusinessId,anEntity);
                if (msg == "Update Fail")
                {
                    ViewBag.errmsg = msg;
                    ViewBag.MarkupPlan = GetMarkupData();
                    return View(anEntity);
                }
                TempData["msg"] = msg + "-UL";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.errmsg = ex.Message;
                ViewBag.MarkupPlan = GetMarkupData();
                return View(anEntity);
            }
        }

        // GET: SampleCRUD/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                ViewBag.MarkupPlan = GetMarkupData();
                BusinessEntity anEntity = aManager.GetanEntityById(id);
                return View(anEntity);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        // POST: SampleCRUD/Delete/5
        [HttpPost]
        public ActionResult Delete(int BusinessId, BusinessEntity anEntity)
        {
            try
            {

                string msg = aManager.Delete(BusinessId);
                if (msg == "Update Fail")
                {
                    ViewBag.errmsg = msg;
                    return View(anEntity);
                }
                TempData["msg"] = msg + "-DL";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.errmsg = ex.Message;
                ViewBag.MarkupPlan = GetMarkupData();
                return View(anEntity);
            }
        }

        List<BusinessEntity> GetList()
        {
            List<BusinessEntity> list=new List<BusinessEntity>();
            list = aManager.GetListDate();

            return list;
        }
        private DataTable GetMarkupData()
        {
            try
            {
               DataSet ds= aManager.GetDate();
                return ds.Tables["MarkupPlane"];
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
    }
}
